// Funzione per gestire l'effetto di apparizione e scomparsa delle immagini
function toggleImages() {
    var image1 = document.getElementById("dynamicImage1");
    var image2 = document.getElementById("dynamicImage2");

    // Se l'immagine corrente è nascosta, mostra l'immagine, altrimenti nascondila
    image1.style.display = (image1.style.display === "none") ? "block" : "none"; /*alterna la visibilità della variabile image1. Se è attualmente visibile, lo nasconde, e se è attualmente nascosto, lo rende visibile */
    image2.style.display = (image2.style.display === "none") ? "block" : "none";

    // Ripeti la funzione dopo un certo intervallo di tempo (ad esempio, 1000 millisecondi o 1 secondo)
    setTimeout(toggleImages, 1000);
}
    // Avvia la funzione di movimento quando il documento è completamente caricato
    document.addEventListener("DOMContentLoaded", function () {
    toggleImages();
});
// Funzione per gestire il movimento laterale delle immagini
function moveImages() {
	var image1 = document.getElementById("dynamicImg1");
	var image2 = document.getElementById("dynamicImg2");

    // Ottieni la posizione attuale delle immagini
    var currentPosition1 = parseInt(image1.style.left) || 0;
    var currentPosition2 = parseInt(image2.style.right) || 0;

    // Se la posizione è inferiore a 0, muovi l'immagine a destra, altrimenti muovila a sinistra
    if (currentPosition1 < 0) {
        // Muovi l'immagine 1 a destra di 10 pixel
        image1.style.left = currentPosition1 + 10 + "px";
        // Muovi l'immagine 2 a sinistra di 10 pixel
        image2.style.right = currentPosition2 - 10 + "px";
    } else {
        // Muovi l'immagine 1 a sinistra di 10 pixel
        image1.style.left = currentPosition1 - 10 + "px"
		// Muovi l'immagine 2 a destra di 10 pixel
        image2.style.right = currentPosition2 + 10 + "px";
    }

    // Ripeti la funzione dopo un certo intervallo di tempo (ad esempio, 500 millisecondi)
    setTimeout(moveImages, 500);
}

    // Avvia la funzione di movimento quando il documento è completamente caricato
    document.addEventListener("DOMContentLoaded", function () {
    moveImages();
});
function moveTitle() {
    var title = document.getElementById('animatedTitle');
    var currentPosition = parseInt(window.getComputedStyle(title).top) || 0; /*metodo getComputedStyle dell'oggetto window per ottenere l'oggetto rappresentante tutti i valori dei CSS applicati all'elemento specificato*/

    // Sposta il titolo di 10 pixel in alto o in basso
    title.style.top = currentPosition + 10 + 'px';

    // Inverti la direzione se il titolo raggiunge una certa posizione
    if (currentPosition >= 10 || currentPosition <= -10) {
        title.style.top = '0';
    }

    // Ripeti la funzione dopo un certo intervallo di tempo (ad esempio, 1000 millisecondi o 1 secondo)
    setTimeout(moveTitle, 1000);
}

// Avvia la funzione quando il documento è completamente caricato
document.addEventListener("DOMContentLoaded", function () {
    moveTitle();
});
